#!/bin/bash

# --- CONFIG ---
LOGO_NAME="logo.jpeg"
LOGO_RENAME=".logo.jpeg"
OMD_DIR="$HOME/Omd"
DESKTOP_DIR="$HOME/Desktop"
ZIP_DIR="$(cd "$(dirname "$0")" && pwd)"
# --- CONFIG END ---

echo "📦 Starting Installation..."

# Step 1: Create Omd directory
mkdir -p "$OMD_DIR"

# Step 2: Copy .sh scripts
find "$ZIP_DIR" -name "*_tutorial.sh" -exec cp {} "$OMD_DIR" \; 2>/dev/null

# Step 3: Copy and rename logo
if [ -f "$ZIP_DIR/$LOGO_NAME" ]; then
  cp "$ZIP_DIR/$LOGO_NAME" "$OMD_DIR/$LOGO_RENAME"
fi

# Step 4: Set permissions
USER_NAME=$(whoami)

# MacOS specific permissions
if [[ "$OSTYPE" == "darwin"* ]]; then
  echo "🖥️ Setting file permissions..."
  chmod -R 755 "$OMD_DIR"  # Make files readable and executable
else
  echo "🔐 Setting ownership and file permissions..."
  sudo chown -R "$USER_NAME:$USER_NAME" "$OMD_DIR"
  sudo chmod -R 777 "$OMD_DIR"  # Open access
fi

# Step 5: Create desktop shortcuts for both Linux and macOS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
  echo "🖥️ Creating desktop shortcuts..."
  find "$ZIP_DIR" -name "*_tutorial.desktop" -exec cp {} "$DESKTOP_DIR" \; 2>/dev/null
elif [[ "$OSTYPE" == "darwin"* ]]; then
  echo "🖥️ Creating desktop shortcuts..."
  for script in "$ZIP_DIR"/*_tutorial.sh; do
    script_name="$(basename "$script" .sh)"
    command_file="$DESKTOP_DIR/$script_name.command"
    echo "#!/bin/bash" > "$command_file"
    echo "bash \"$OMD_DIR/$script_name.sh\"" >> "$command_file"
    chmod +x "$command_file"  # Make the command file executable
  done
fi

# Step 6: Done!
echo -e "\n✅ Installation complete!"
echo "👉 Check your Omd directory at: $OMD_DIR"
echo "👉 Double-click any shortcuts on your Desktop to start your learning journey."
echo -e "💡 If shortcuts won’t launch, right-click > 'Allow Launching' (Linux only) \c"

sleep 20

exit 0
